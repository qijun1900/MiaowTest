var express = require('express');
const ProductController = require('../../controllers/user/ProductController');
var ProductRouter = express.Router();







module.exports = ProductRouter; 