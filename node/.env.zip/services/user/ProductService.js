const ProductModel = require('../../models/ProductModel')
const ProductService ={

}




module.exports = ProductService 