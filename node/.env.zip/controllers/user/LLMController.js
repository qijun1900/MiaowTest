const LLMService = require("../../services/user/LLMService");

const LLMController ={
    sendExamAIanalyse:async (req,res)=>{
        try {
            const { message, QuestionID ,Type,prompt,model} = req.body; // 从请求体中获取问题和题目ID,如果QuestionID不存在，则调用大模型api获得
    
            const newmessage = prompt+":"+map; // 拼接提示词和映射后的问题

            const result = await LLMService.sendExamAIanalyse(newmessage, QuestionID,Type,model); // 调用服务层的sendExamAIanalyse方法
            res.send({
                code: 200,
                ActionType: "OK",
                data: result ,// 返回服务层的响应结果
            });
        } 
        catch (error) {
            console.error('Error fetching sendExamAIanalyse details:', error); // 处理错误
        }
    },
    UserChat:async (req,res)=>{
        try {
            const {message,model} = req.body; 
            console.log("用户输入的问题:", message, "模型:", model);
            const result = await LLMService.UserChat(message,model) 
            res.send({
                code: 200,
                ActionType: "OK",
                data: result // 返回服务层的响应结果 
            })
        } catch (error) {
            console.error('Error fetching UserChat details:', error); // 处理错误 
        }
    },
    getLLMList:async (req,res)=>{
        try {
            const result = await LLMService.getLLMList() // 调用服务层的getLLMList方法 
            res.send({
                code: 200,
                ActionType: "OK",
                data: result // 返回服务层的响应结果
            })
        } catch (error) {
            console.error('Error fetching getLLMList details:', error); // 处理错误
        }
        
    },
    postTranslateWorld:async (req,res)=>{
        try {
            const {word} = req.body; 
            console.log("要翻译的单词:", word);
            const result = await LLMService.postTranslateWorld(word) // 调用服务层的postTranslateWorld方法
            res.send({
                code: 200,
                ActionType: "OK",
                data: result // 返回服务层的响应结果
            })
        } catch (error) {
            console.error('Error fetching postTranslateWorld details:', error); // 处理错误
        }
    }

}
module.exports = LLMController
